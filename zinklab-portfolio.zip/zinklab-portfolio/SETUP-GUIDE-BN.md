# ZinkLab Portfolio — GitHub + Vercel সেটআপ গাইড (বাংলা)

এই ফোল্ডারটাই আপনার পুরো ওয়েবসাইট। ভেতরে আছে:

```
zinklab-portfolio/
├── index.html        ← মূল ওয়েবসাইট
├── images/           ← সব ছবি এখানে
│   ├── logo.png
│   ├── landing-page-1.webp
│   ├── landing-page-2.webp
│   ├── poster-1.jpg … poster-6.jpg
│   ├── poster-7.png   ← এখন placeholder, আপনার আসল ছবি দিয়ে বদলাতে হবে
│   └── poster-8.png   ← এখন placeholder, আপনার আসল ছবি দিয়ে বদলাতে হবে
├── README.md
└── SETUP-GUIDE-BN.md ← এই ফাইল
```

---

## ১. ছবির নাম (সবচেয়ে গুরুত্বপূর্ণ)

`index.html` ফাইলটা ছবিগুলোকে **নাম ধরে** খোঁজে। তাই আপনি নতুন ছবি দিলে নাম **হুবহু** নিচের মতো হতে হবে।

| ওয়েবসাইটের কোথায় | ফাইলের নাম (হুবহু) |
|---|---|
| উপরে ডানদিকের লোগো (এবং ট্যাবের আইকন) | `logo.png` |
| Landing Pages — ১ম কার্ড (MJD Garden) | `landing-page-1.webp` |
| Landing Pages — ৩য় কার্ড (Rossoblu) | `landing-page-2.webp` |
| Poster 1 (Élique social media) | `poster-1.jpg` |
| Poster 2 (Microsoft thumbnail) | `poster-2.jpg` |
| Poster 3 (Best phone review) | `poster-3.jpg` |
| Poster 4 (Luna Daily Cream) | `poster-4.jpg` |
| Poster 5 (MJD Garden Services) | `poster-5.jpg` |
| Poster 6 (Warner & Spencer Hotel) | `poster-6.jpg` |
| Poster 7 | `poster-7.png` |
| Poster 8 | `poster-8.png` |

### নাম দেওয়ার ৪টি নিয়ম
1. **সব ছোট হাতের (lowercase) অক্ষর** — `Poster-1.jpg` লিখলে ছবি আসবে না, `poster-1.jpg` লিখতে হবে।
2. **এক্সটেনশন মিলতে হবে** — `poster-1.jpg` এর জায়গায় `poster-1.png` দিলে আসবে না। (নিচে দেখুন কীভাবে ঠিক করবেন)
3. **নামে স্পেস দেবেন না** — `poster 1.jpg` নয়, `poster-1.jpg`।
4. **একই নামে আবার আপলোড করলে পুরনো ছবি বদলে যায়** — ওয়েবসাইটের কোড ছুঁতে হয় না।

### আপনার ছবি যদি অন্য ফরম্যাটের হয় (যেমন .png বা .jpeg)?
সবচেয়ে সহজ উপায়: ছবিটাকে `.jpg` বানিয়ে নিন (যেকোনো free online converter দিয়ে)। অথবা `index.html` ফাইলে ওই ছবির লাইন খুঁজে এক্সটেনশন বদলে দিন, যেমন `images/poster-3.jpg` → `images/poster-3.png`।

### ⚠️ poster-7 ও poster-8 সম্পর্কে
আগের ফাইলে এই দুটি ছবি Blogger-এর লিংক থেকে আসত। সেগুলো ছিল **ছোট (৩২০px) thumbnail** ভার্সন। এখন এই দুটি জায়গায় একটা **placeholder ছবি** বসানো আছে (যাতে লেখা "PLACEHOLDER")।

আপনাকে করতে হবে: আপনার আসল poster দুটি (বড় সাইজে, যেমন ১৫০০px+ চওড়া) `poster-7.png` ও `poster-8.png` নামে `images` ফোল্ডারে আপলোড করা। না করলে ওয়েবসাইটে "PLACEHOLDER" ছবিই দেখা যাবে।

*(পুরনো Blogger লিংক দুটি এই ফাইলের একদম শেষে রেখে দিয়েছি, কাজে লাগলে।)*

---

## ২. GitHub-এ আপলোড (কোনো কমান্ড/টার্মিনাল ছাড়া)

### প্রথমবার
1. <https://github.com> এ গিয়ে Sign up / Sign in করুন।
2. উপরে ডানদিকে **+** চিহ্নে ক্লিক করে **New repository** চাপুন।
3. **Repository name** এ লিখুন: `zinklab-portfolio`
4. **Public** বা **Private** — যেকোনোটা (Vercel দুটোতেই কাজ করে)।
5. **"Add a README file" টিক দেবেন না।** তারপর **Create repository** চাপুন।
6. নতুন পেজে **"uploading an existing file"** লেখা লিংকে ক্লিক করুন।
7. কম্পিউটারে `zinklab-portfolio` ফোল্ডারটা খুলুন। ভেতরের সবকিছু (`index.html`, `images` ফোল্ডার, `README.md`, ইত্যাদি) সিলেক্ট করে ব্রাউজারের ওই বক্সে **drag & drop** করুন।
   - `images` ফোল্ডারটা আস্ত ফোল্ডার হিসেবেই টেনে আনুন (Chrome/Edge-এ কাজ করে)।
8. সব ফাইল আপলোড হয়ে গেলে নিচে **Commit changes** (সবুজ বাটন) চাপুন।

### পরে ছবি বদলাতে চাইলে
1. GitHub-এ আপনার repository খুলুন → `images` ফোল্ডারে ঢুকুন।
2. **Add file → Upload files** চাপুন।
3. নতুন ছবিটা **ঠিক আগের নামে** (যেমন `poster-7.png`) টেনে আনুন → **Commit changes**।
4. পুরনো ছবি অটোমেটিক বদলে যাবে, আর Vercel নিজে থেকে নতুন করে ওয়েবসাইট বানাবে (১–২ মিনিট)।

> নতুন ছবি যোগ করতে চাইলে (যেমন `poster-9.jpg`) সেটা `index.html` এর কোডে যোগ করতে হবে। দরকার হলে আমাকে বলবেন, আমি করে দেব।

---

## ৩. Vercel-এ Deploy

1. <https://vercel.com> এ যান → **Sign Up** → **Continue with GitHub** (একই GitHub অ্যাকাউন্ট)।
2. ড্যাশবোর্ডে **Add New… → Project** চাপুন।
3. তালিকায় `zinklab-portfolio` দেখা যাবে → পাশের **Import** চাপুন।
   - না দেখালে **Adjust GitHub App Permissions** চাপুন এবং repository-টাকে অনুমতি দিন।
4. সেটিংস পেজে কিছুই বদলাতে হবে না:
   - **Framework Preset:** `Other` (অথবা অটো-ডিটেক্ট)
   - **Build Command / Output Directory:** ফাঁকা রাখুন
5. **Deploy** চাপুন। ১ মিনিটের মধ্যে `https://zinklab-portfolio-xxxx.vercel.app` ধরনের লিংক পাবেন।
6. লিংক খুলে চেক করুন: লোগো, ছবি, Contact Us বাটন, ফর্ম।

এরপর GitHub-এ কিছু বদলালেই Vercel নিজে থেকে নতুন ভার্সন Deploy করে দেবে।

### নিজের ডোমেইন লাগাতে চাইলে
Vercel-এ প্রজেক্ট খুলুন → **Settings → Domains** → আপনার ডোমেইন লিখে **Add** করুন। Vercel যে DNS রেকর্ড দেখাবে সেটা ডোমেইন কেনা কোম্পানির সেটিংসে বসাতে হবে।

---

## ৪. জেনে রাখা ভালো

- **Contact form ও Newsletter** ফর্ম `formsubmit.co` সার্ভিসের মাধ্যমে `zinklabofficial@gmail.com` এ মেইল পাঠায়। **প্রথমবার** ফর্ম সাবমিট করলে FormSubmit ওই Gmail-এ একটা **confirmation মেইল** পাঠাবে। সেই মেইলে "Activate" লিংকে ক্লিক না করলে পরের মেসেজগুলো আসবে না। (Spam ফোল্ডারও দেখবেন।)
- **Demo Projects-এর "Preview"** (MJD ও Rossoblu) এর পুরো ওয়েবসাইট `index.html` ফাইলের ভেতরেই ঢোকানো আছে। এ কারণে `index.html` ফাইলের সাইজ প্রায় ৬MB। GitHub ও Vercel দুটোতেই এতে সমস্যা নেই।
- ওয়েবসাইট লোকালি দেখতে চাইলে `index.html` ডাবল-ক্লিক করে ব্রাউজারে খুললেই হবে (ইন্টারনেট থাকলে ফন্ট আসবে)।

---

### পুরনো Blogger লিংক (শুধু রেফারেন্সের জন্য)
- Poster 7 (আগে): `https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh4fIcKFGKKojJQK3d4lXCALS1KiR0QPXaIJ9VacYN5TL49WL_O0vSdkdgafdXUr9DyXMQfTS200D5l-O3dvlYrqY_xSp5uL_cpHaQA6slP5wbuOuRCCPEmnlk8k7v1knQlnpqXDq8mNc7VE1xfZZ7zfOqFH39SNKRqos9dSXEk0MP7x7LbvRj6OueYXiyj/s320/tips.png`
- Poster 8 (আগে): `https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhvqW5Dyndsltj3TMRHLgNpTu3_9e3DmvtyyuMxijjZQcSvv-bTvWCM-BURnomw5_t9orG_shG3p5UT8_qtbrABWQh25NJ4JOS7wB4znvH-vapiEgZh45LihM6mg5qWIRwxq71BbfoUbid1QVMQmuHiUdCC6jWOFtVpOftoS-9M_fMVdQTtuwywYuPhE6Jp/s320/Screenshot%202026-11-05%20220431.png`

(লিংকের শেষে `/s320/` মানে ছোট সাইজ। Blogger থেকে বড় ছবি পেতে লিংকের `s320` বদলে `s0` লিখলে আসল সাইজের ছবি খোলে।)
